Linux server
============

  server         the server binary, x86-64, Release build
  libuv.so.1     the one shared library it needs beside the system ones

Running
-------
  ./server                      # foreground, port 23507
  ./server -d -p 23507          # daemon
  kill $(cat server.pid)        # graceful shutdown

The binary locates libuv.so.1 next to itself ($ORIGIN in its RUNPATH), so no
LD_LIBRARY_PATH is needed; move the two files together and they keep working.

result.csv, skip_report.txt and logs/ are written to the working directory.

Anything else - building from source, running the server under Docker, the
network architecture, the memory strategy, the corrupted-data handling - is in
the two documents one and two levels up:

  ../../README.txt              this package: layout, running, verifying
  ../../03.readme/README.md     the full documentation
