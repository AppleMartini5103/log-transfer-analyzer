log-transfer-analyzer — submission package
==========================================

Layout follows the deliverables list in the assignment.

  01.full-source-code/
      personal-github-url.txt   Repository link. These binaries were built from commit
                                0cc8298 there; later commits do not affect them.

  02.binary-file/
      client/client.exe         Windows client (Win32/DX11). Self-contained: libuv and the
                                MSVC runtime are linked in, so nothing needs to sit beside it.
      server/server             Linux server, x86-64. Release build, Ubuntu 24.04.4 LTS, GCC 13.3.
      server/libuv.so.1         The one shared library the server needs beside the system ones.
      server/README.txt         How to run the server; points back here for everything else.

  03.readme/README.md           Build instructions, network architecture, memory strategy,
                                corrupted-data handling, the result.csv contract and the
                                client's skipped-line warning. Identical to the repository copy.

  SHA256SUMS                    Checksums of the four files that make up the
                                deliverable: the three binaries and README.md.
                                The text files that describe the package - both
                                README.txt files and the URL note - are not covered.

Running the Linux server
------------------------
  cd 02.binary-file/server && ./server        # foreground, port 23507

The binary locates libuv.so.1 next to itself ($ORIGIN in its RUNPATH), so no
LD_LIBRARY_PATH is needed; move the two files together and they keep working.
Move server on its own and it will not start - that is the same mechanism seen
from the other side, not a packaging mistake.

result.csv, skip_report.txt and logs/ are written to the working directory.

Building from source, or running under Docker
---------------------------------------------
Nothing here needs to be built. Both binaries are in 02.binary-file/ and
client.exe is self-contained - no DLLs, no VC++ redistributable. The steps below
are for reviewing the build, not a prerequisite for running anything.

This package holds binaries only - the source is in the repository linked above.
From a clone of it:

  ./install_deps_linux.sh     # only if the toolchain (g++, cmake) is missing
  ./build_project_linux.sh    # build + 185 unit tests

Or, without installing a toolchain at all:

  ./docker/build_images.sh    # base image, then app image, in that order
  docker compose up           # port 23507; result.csv lands in ./out

Verifying
---------
Linux, or Git Bash on Windows:

  sha256sum -c SHA256SUMS       # run from this folder

Windows PowerShell has no sha256sum; this does the same check:

  Get-Content SHA256SUMS | ForEach-Object { $h,$f = $_ -split '\s+',2; $f=$f.Trim();
    $a=(Get-FileHash $f -Algorithm SHA256).Hash
    "{0}: {1}" -f $f, $(if ($a -eq $h.ToUpper()) {'OK'} else {'FAILED'}) }

Anything else - building from source, Smart App Control blocking client.exe, the state
machine, the validation pipeline - is covered in 03.readme/README.md.
